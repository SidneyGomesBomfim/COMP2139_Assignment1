using GBC_Travel.Models;

namespace GBC_Travel.Data;

// The seed data. EF Core inserts these rows when the migration is applied.
// (HasData needs fixed values, so the dates are written out.)
public static class SeedData
{
    public static Flight[] Flights() => new[]
    {
        new Flight { Id = 1, Airline = "Air Canada", FlightNumber = "AC123", Origin = "Toronto (YYZ)", Destination = "Vancouver (YVR)",
            DepartureTime = new DateTime(2026, 11, 2, 8, 15, 0), ArrivalTime = new DateTime(2026, 11, 2, 10, 40, 0),
            Price = 349.00m, SeatsAvailable = 24, Stops = 0 },
        new Flight { Id = 2, Airline = "WestJet", FlightNumber = "WS705", Origin = "Toronto (YYZ)", Destination = "Vancouver (YVR)",
            DepartureTime = new DateTime(2026, 11, 2, 11, 30, 0), ArrivalTime = new DateTime(2026, 11, 2, 13, 52, 0),
            Price = 372.00m, SeatsAvailable = 12, Stops = 0 },
        new Flight { Id = 3, Airline = "Porter", FlightNumber = "PD511", Origin = "Toronto (YYZ)", Destination = "Vancouver (YVR)",
            DepartureTime = new DateTime(2026, 11, 2, 14, 5, 0), ArrivalTime = new DateTime(2026, 11, 2, 18, 20, 0),
            Price = 398.00m, SeatsAvailable = 8, Stops = 1 },
        new Flight { Id = 4, Airline = "Air Canada", FlightNumber = "AC131", Origin = "Toronto (YYZ)", Destination = "Vancouver (YVR)",
            DepartureTime = new DateTime(2026, 11, 2, 19, 45, 0), ArrivalTime = new DateTime(2026, 11, 2, 22, 10, 0),
            Price = 415.00m, SeatsAvailable = 30, Stops = 0 },
        new Flight { Id = 5, Airline = "Air Canada", FlightNumber = "AC401", Origin = "Toronto (YYZ)", Destination = "Montreal (YUL)",
            DepartureTime = new DateTime(2026, 11, 3, 7, 0, 0), ArrivalTime = new DateTime(2026, 11, 3, 8, 25, 0),
            Price = 179.00m, SeatsAvailable = 40, Stops = 0 },
        new Flight { Id = 6, Airline = "WestJet", FlightNumber = "WS318", Origin = "Vancouver (YVR)", Destination = "Toronto (YYZ)",
            DepartureTime = new DateTime(2026, 11, 5, 9, 10, 0), ArrivalTime = new DateTime(2026, 11, 5, 16, 55, 0),
            Price = 389.00m, SeatsAvailable = 15, Stops = 0 },
        new Flight { Id = 7, Airline = "Porter", FlightNumber = "PD620", Origin = "Toronto (YYZ)", Destination = "Calgary (YYC)",
            DepartureTime = new DateTime(2026, 11, 4, 12, 20, 0), ArrivalTime = new DateTime(2026, 11, 4, 14, 35, 0),
            Price = 329.00m, SeatsAvailable = 6, Stops = 0 },
        new Flight { Id = 8, Airline = "Air Canada", FlightNumber = "AC808", Origin = "Montreal (YUL)", Destination = "Vancouver (YVR)",
            DepartureTime = new DateTime(2026, 11, 6, 6, 45, 0), ArrivalTime = new DateTime(2026, 11, 6, 13, 30, 0),
            Price = 455.00m, SeatsAvailable = 0, Stops = 1 },
    };

    public static Hotel[] Hotels() => new[]
    {
        new Hotel { Id = 1, Name = "Harbourfront Inn", Location = "Toronto", Address = "235 Queens Quay W",
            StarRating = 4, PricePerNight = 189.00m, RoomsAvailable = 12,
            Amenities = "Free Wi-Fi,Pool,Parking,Breakfast,Gym",
            Description = "A waterfront hotel steps from the ferry docks, the CN Tower and the downtown core." },
        new Hotel { Id = 2, Name = "Old Port Suites", Location = "Montreal", Address = "88 Rue de la Commune E",
            StarRating = 3, PricePerNight = 159.00m, RoomsAvailable = 20,
            Amenities = "Free Wi-Fi,Breakfast,Kitchenette",
            Description = "Spacious suites in a restored stone building in the heart of Old Montreal." },
        new Hotel { Id = 3, Name = "Maple Leaf Lodge", Location = "Vancouver", Address = "1200 W Georgia St",
            StarRating = 5, PricePerNight = 279.00m, RoomsAvailable = 6,
            Amenities = "Free Wi-Fi,Pool,Spa,Parking,Gym,Restaurant",
            Description = "A five-star downtown lodge with mountain views and a full-service spa." },
        new Hotel { Id = 4, Name = "Rocky View Hotel", Location = "Calgary", Address = "410 8 Ave SW",
            StarRating = 4, PricePerNight = 199.00m, RoomsAvailable = 15,
            Amenities = "Free Wi-Fi,Parking,Breakfast,Gym",
            Description = "A modern hotel in downtown Calgary with easy access to the Stampede grounds." },
        new Hotel { Id = 5, Name = "Budget Stay Downtown", Location = "Toronto", Address = "55 Dundas St E",
            StarRating = 2, PricePerNight = 99.00m, RoomsAvailable = 30,
            Amenities = "Free Wi-Fi,Air conditioning",
            Description = "Simple, clean rooms at a low price, close to the subway and Eaton Centre." },
        new Hotel { Id = 6, Name = "Stanley Park Retreat", Location = "Vancouver", Address = "2030 Barclay St",
            StarRating = 5, PricePerNight = 329.00m, RoomsAvailable = 2,
            Amenities = "Free Wi-Fi,Pool,Spa,Parking,Breakfast,Restaurant",
            Description = "A boutique retreat beside Stanley Park, with only a few rooms left this season." },
    };
}
